<?php

namespace App\Http\Controllers;
use App\Helpers\AuthChecker;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class JBwbPDSController extends Controller
{
    public function schemeSelection(Request $request)
    {
        $auth = AuthChecker::VerifierChecker();
        if ($auth) {
            $userId = AuthChecker::getUserId();
            $designation_id = AuthChecker::getDesignationId();
            $scheme_list = DB::select(DB::raw("select id,scheme_name from m_scheme where id  in (select scheme_id from duty_assignement where user_id=" . $userId . " and is_active=1) and is_active=1 order by scheme_name"));

            return view('jbwbpds.schemeSelection',[
                'designation_id'=> $designation_id,
               'scheme_list' => $scheme_list
            ]);
        }
    }
}
